#!/bin/bash

APP_NAME="NodeBox"
INSTALL_DIR="$HOME/.local/share/$APP_NAME"
DESKTOP_FILE="$HOME/.local/share/applications/$APP_NAME.desktop"

# Binary ko install karna
mkdir -p "$INSTALL_DIR"
cp NodeBox "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/$APP_NAME"

# Icon copy karna
mkdir -p "$HOME/.local/share/icons"
cp ./NodeBox.png "$HOME/.local/share/icons/$APP_NAME.png"

# Desktop entry banana
cat > "$DESKTOP_FILE" <<EOL
[Desktop Entry]
Name=$APP_NAME
Exec=$INSTALL_DIR/$APP_NAME
Icon=$HOME/.local/share/icons/$APP_NAME.png
Type=Application
Categories=Utility;Development;
Terminal=false
EOL

# Desktop database update
update-desktop-database ~/.local/share/applications

echo "$APP_NAME installed successfully!"
